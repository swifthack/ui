const express = require('express');
const { ethers } = require("ethers");
const fs = require("fs");
const app = express();
const port = 3000;
const cors = require('cors');

const dbPool = require('./config/db'); 
const dexRoutes = require('./routes/dexRoutes');
const bankAdminRoutes = require('./routes/bankAdminRoutes');
const customerRoutes = require('./routes/customerRoutes');
// Load environment variables
require('dotenv').config();
app.use(cors());
app.use(express.json());

app.use('/api/dex', dexRoutes);
app.use('/api/bankAdmin', bankAdminRoutes);
app.use('/api/customers', customerRoutes);

// --- Start the Express Server ---
app.listen(port, () => {
  console.log(`Express server listening at http://localhost:${port}`);
  });