const express = require('express');
const router = express.Router();
const { ethers } = require('ethers');
const fs = require('fs');
const path = require('path');
require('dotenv').config();
const pool = require('../config/db'); 

const abi = JSON.parse(fs.readFileSync("./abi/CustodialWallet.json")).abi;
const factoryAbi = JSON.parse(fs.readFileSync("./abi/CustodialWalletFactory.json")).abi;
const TESTUSDC_ABI = JSON.parse(fs.readFileSync("./abi/TestUSDC.json")).abi;

const INFURA_API_KEY = process.env.INFURA_API_KEY;

// Infura URL for Sepolia
const infuraUrl = `https://sepolia.infura.io/v3/${INFURA_API_KEY}`;
let owners = {};
let wallets = [];

const provider = new ethers.JsonRpcProvider(infuraUrl);
const signer = new ethers.Wallet(process.env.SIGNER_PRIVATE_KEY, provider);

const testUSDC = new ethers.Contract(process.env.TESTUSDC_ADDRESS, TESTUSDC_ABI, signer);
const factory = new ethers.Contract(process.env.FACTORY_ADDRESS, factoryAbi, signer);
/**
 * create a new custodial wallet
 * @param {string} ownerAddress - the address of the owner
 * @returns {string} walletAddress - the address of the new wallet
 */
router.post('/createCustodialWallet', async (req, res) => {
  try{
    //NOTE: Need to pass username, ownerAdress and cointype(currency),vaspUser
    const { user_name,ownerAddress,coinType,vaspUser } = req.body;
    console.log("createCustodialWallet:", user_name, ownerAddress, coinType, vaspUser);
    if (!ethers.isAddress(ownerAddress)) return res.status(400).json({ error: 'Invalid address' });
    const tx = await factory.createWallet(process.env.TESTUSDC_ADDRESS, ownerAddress);
    const receipt = await tx.wait();
    const event = receipt.logs.map(log => {
      try { return factory.interface.parseLog(log); } catch { return null; }
    }).find(e => e && e.name === 'WalletCreated');
      const walletAddress = event.args.wallet;
      console.log(`New Custodial wallet created: ${walletAddress}`);
      wallets.push(walletAddress);
      const query = `
        INSERT INTO custodial_wallets (username, owner_address, coin_type, vasp_user, wallet_address,  tx_hash)
        VALUES ($1, $2, $3, $4, $5, $6)
      `;
      const values = [user_name, ownerAddress, coinType, vaspUser, walletAddress,  tx.hash];
      await pool.query(query, values);
      res.json({ wallet: walletAddress });
    }catch (err) {
      console.error(err);
      return res.status(500).json({ error: 'Internal Server Error' });
    }
});
/**get API to  custodailwallet for a specific user
 *  */ 

router.get('/getCustodialWallet', async (req, res) => {
  try{
    const { username, ownerAddress } = req.query;
    let baseQuery = 'SELECT * FROM custodial_wallets';
    const filters = [];
    const values = [];

    if (username) {
      filters.push('username = $' + (values.length + 1));
      values.push(username);
    }

    if (ownerAddress) {
      filters.push('owner_address = $' + (values.length + 1));
      values.push(ownerAddress);
    }

    if (filters.length > 0) {
      baseQuery += ' WHERE ' + filters.join(' AND ');
    }
    const { rows } = await pool.query(baseQuery, values);
    res.json({ wallets: rows });
  } catch (err) {
    console.error('Error fetching custodial wallets:', err);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});



/**
 * @swagger
 * /api/customers:
 *   post:
 *     summary: Create a new customer record
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Customer'
 *     responses:
 *       201:
 *         description: Customer created successfully
 *       500:
 *         description: Internal server error
 */
router.post('/createCustomer', async (req, res) => {
  const {
    CUST_ID,
    UserName,
    email,
    organization,
    GLEI,
    status,
    wallets,
    last_login
  } = req.body;

  try {
    const checkOwner = await pool.query(
      'SELECT * FROM owner_addresses WHERE username = $1',
      [email]);
     console.log("checkOwner:", checkOwner.rowCount);
      if (checkOwner.rowCount === 0) {
        console.log(`No owner address found for email: ${email}`);
        return res.status(404).json({ message: 'Owner address not found for this email' });
      }else if (checkOwner.rowCount >= 1) {
        const result = await pool.query(
          `INSERT INTO customers (
            "CUST_ID", "UserName", email, organization, "GLEI",
            status, wallets, last_login
          ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
          [CUST_ID, UserName, email, organization, GLEI, status, wallets, last_login]
        );
        res.status(201).json(result.rows[0]);
      }
    
  } catch (err) {
    console.error('Error inserting customer:', err);
    res.status(500).json({ message: 'Internal server error' });
  }
});


router.get('/getOwnerAddress', async (req, res) => {
  const { username } = req.query;

  if (!username) {
    return res.status(400).json({ error: 'Username is required' });
  }

  try {
    const query = `
      SELECT address, private_key 
      FROM owner_addresses 
      WHERE username = $1
    `;
    const values = [username];
    const { rows } = await pool.query(query, values);

    if (rows.length === 0) {
      return res.status(404).json({ error: 'No address found for that username' });
    }
    console.log(`Address found for username ${username}:`, rows[0]);
    const { address, private_key } = rows[0];
    res.json({ address, privateKey: private_key });
  } catch (err) {
    console.error('Error fetching owner address:', err);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

/**
 * @swagger
 * /api/customers:
 *   get:
 *     summary: Retrieve customers with optional filters
 *     parameters:
 *       - name: email
 *         in: query
 *         schema:
 *           type: string
 *       - name: status
 *         in: query
 *         schema:
 *           type: string
 *       - name: organization
 *         in: query
 *         schema:
 *           type: string
 *       - name: UserName
 *         in: query
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Customers retrieved
 *       500:
 *         description: Internal server error
 */
router.get('/customers', async (req, res) => {
  const filters = req.query;
  const conditions = [];
  const values = [];

  Object.entries(filters).forEach(([key, value], idx) => {
    conditions.push(`"${key}" = $${idx + 1}`);
    values.push(value);
  });

  const query = conditions.length
    ? `SELECT * FROM customers WHERE ${conditions.join(' AND ')}`
    : `SELECT * FROM customers`;

  try {
    const result = await pool.query(query, values);
    res.json({
      message: 'Customer data retrieved',
      data: result.rows
    });
  } catch (err) {
    console.error('Error fetching customers:', err);
    res.status(500).json({ message: 'Internal server error' });
  }
});


router.get('/custodialWallets', async (req, res) => {

  let query = 'SELECT * FROM custodial_wallets';

  try {
    const result = await pool.query(query);
    console.log("Custodial wallets fetched:", result.rows);
    res.json({
      message: 'Custodial wallets data retrieved',
      data: result.rows
    });
  } catch (err) {
    console.error('Error fetching Custodial wallets:', err);
    res.status(500).json({ message: 'Internal server error' });
  }
});


module.exports = router;