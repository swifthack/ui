const express = require('express');
const router = express.Router();
const { ethers } = require('ethers');
const fs = require('fs');
const path = require('path');
require('dotenv').config();
const pool = require('../config/db'); 

const abi = JSON.parse(fs.readFileSync("./abi/CustodialWallet.json")).abi;
const factoryAbi = JSON.parse(fs.readFileSync("./abi/CustodialWalletFactory.json")).abi;
const TESTUSDC_ABI = JSON.parse(fs.readFileSync("./abi/TestUSDC.json")).abi;

const INFURA_API_KEY = process.env.INFURA_API_KEY;

// Infura URL for Sepolia
const infuraUrl = `https://sepolia.infura.io/v3/${INFURA_API_KEY}`;
let owners = {};
let wallets = [];

const provider = new ethers.JsonRpcProvider(infuraUrl);
const signer = new ethers.Wallet(process.env.SIGNER_PRIVATE_KEY, provider);

const testUSDC = new ethers.Contract(process.env.TESTUSDC_ADDRESS, TESTUSDC_ABI, signer);
const factory = new ethers.Contract(process.env.FACTORY_ADDRESS, factoryAbi, signer);


router.get('/getCustodialWallet', async (req, res) => {
  try{
    const { username } = req.query;
    let baseQuery = 'SELECT * FROM custodial_wallets where username = $1';
    const values = [username];  
    
    const result = await pool.query(baseQuery, values);
    console.log("Custodial wallets for user:", username, result.rows);
    res.json({
        message: 'Custodial wallets data retrieved',
        data: result.rows
      });

  } catch (err) {
    console.error('Error fetching custodial wallets:', err);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

module.exports = router;