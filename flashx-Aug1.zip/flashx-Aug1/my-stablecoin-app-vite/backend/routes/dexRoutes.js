const express = require('express');
const router = express.Router();
const { ethers } = require('ethers');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const pool = require('../config/db'); 

//const dotenv = require("dotenv");
const abi = JSON.parse(fs.readFileSync("./abi/CustodialWallet.json")).abi;
const factoryAbi = JSON.parse(fs.readFileSync("./abi/CustodialWalletFactory.json")).abi;
const TESTUSDC_ABI = JSON.parse(fs.readFileSync("./abi/TestUSDC.json")).abi;

const INFURA_API_KEY = process.env.INFURA_API_KEY;

// Infura URL for Sepolia
const infuraUrl = `https://sepolia.infura.io/v3/${INFURA_API_KEY}`;
let owners = {};
let wallets = [];

const provider = new ethers.JsonRpcProvider(infuraUrl);
const signer = new ethers.Wallet(process.env.SIGNER_PRIVATE_KEY, provider);

const testUSDC = new ethers.Contract(process.env.TESTUSDC_ADDRESS, TESTUSDC_ABI, signer);
const factory = new ethers.Contract(process.env.FACTORY_ADDRESS, factoryAbi, signer);
/***********
 * 
 * API's for DEXI 
 *****************/
/**
 * utility function to create a new owner address
 * need to store this address in database per owner
 */

router.post('/createOwnerAddress', async (req, res) => {
  try{
    const { user_name } = req.body;
    //write logic to check if owner exists in database
    const checkQuery = `SELECT address FROM owner_addresses WHERE username = $1`;
    const userName = [user_name];
    const checkUserExists = await pool.query(checkQuery, userName);    
    if (checkUserExists.rows.length > 0) {
        res.json({
            message: 'Owner address already exists',
        });
    } else {
          // if not, create a new owner address
      // for now, we will just create a random address
      
      const ownerwalletAddress = ethers.Wallet.createRandom();
      console.log("Address:", ownerwalletAddress.address);
      console.log("Private Key:", ownerwalletAddress.privateKey); // store securely!
    //TODO insert into DB address, privateky,username-- done
      // Insert into DB
      const query = `
        INSERT INTO owner_addresses (username, address, private_key)
        VALUES ($1, $2, $3)
        ON CONFLICT (address) DO NOTHING
      `;
      const values = [user_name, ownerwalletAddress.address,ownerwalletAddress.privateKey];
      await pool.query(query, values);
      res.json({
          address: ownerwalletAddress.address,
          privateKey: ownerwalletAddress.privateKey
        });
      return ownerwalletAddress.address;
    }
   
  }catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create owner address' });
  }
});


router.get('/getOwnerAddress', async (req, res) => {
    const user_name = req.query.user_name;
    try{
        const query = `
            SELECT address, private_key FROM owner_addresses WHERE username = $1
        `;
        const values = [user_name];
        const result = await pool.query(query, values);    
        if (result.rows.length > 0) {
            const ownerAddress = result.rows[0];
            res.json({
                address: ownerAddress.address,
                privateKey: ownerAddress.private_key
            });
        } else {
            res.status(404).json({ error: 'Owner address not found' });
        }
    }catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Failed to retrieve owner address' });
    }
});
/**
 * Mint USDC tokens (simulating stablecoin minting)
 */
router.post('/mint', async (req, res) => {
    try {
  
      const { user_name,toAddress, amount,coinType } = req.body;
      console.log(`Minting ${amount} USDC to ${toAddress}`);
      const mintAmount = ethers.parseUnits(amount.toString(), 6);
      const tx = await testUSDC.mint(toAddress, mintAmount);
      await tx.wait();
        //TODO insert into DB user_name,toAddress, amount,coinType, tnxDate & tnxhash (tx.hash) -- done
      const query = `
        INSERT INTO mint_transactions (username, to_address, amount, coin_type,  tx_hash)
        VALUES ($1, $2, $3, $4, $5)
      `;
      const values = [user_name, toAddress, amount, coinType,  tx.hash];
      await pool.query(query, values);
      res.json({ txHash: tx.hash });
  
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Failed to create wallet' });
    }
  });

  /**
   * 
   * Approve USDC tokens for VASP to spend on behalf of the owner
   * This is a crucial step in the DEX process, allowing the VASP to manage
   * the owner's USDC tokens for trading or other operations.
   */

  
   router.post('/approve', async (req, res) => {
    try {
        const { user_name,ownerPrivateKey,amount } = req.body;
        console.log('inside Approve');
        const OWNER_PRIVATE_KEY = ownerPrivateKey;
        const ownerWallet = new ethers.Wallet(OWNER_PRIVATE_KEY, provider);
        console.log('after ownerWallet');
        const ownerAddress = await ownerWallet.getAddress();
        console.log('after ownerAddress');
        const VASP_ADDRESS = signer.address; // VASP address is the signer address
        // 🎯  Load TestUSDC contract
        const token = new ethers.Contract(process.env.TESTUSDC_ADDRESS, TESTUSDC_ABI, ownerWallet);
    
        console.log(`Approving VASP (${VASP_ADDRESS}) to spend USDC from Owner (${ownerAddress})...`);
    
        // 📤  Send approval
        const tx = await token.approve(VASP_ADDRESS, ethers.parseUnits(amount, 6));
        await tx.wait();
    
        // 🔎  Check allowance
        const allowance = await token.allowance(ownerAddress, VASP_ADDRESS);
        console.log("✅  Approval complete. Allowance:", ethers.formatUnits(allowance, 6));
        //TODO insert into DB username,date of transaction , amount & txhash -- done
        // After successful approval and getting tx.hash
        const insertQuery = `
          INSERT INTO wallet_approvals (user_name, amount, tx_hash)
          VALUES ($1, $2, $3)
        `; 
        const insertValues = [user_name, amount, tx.hash];
      
        await pool.query(insertQuery, insertValues);
        console.log('Approval record inserted into DB');
        res.json({ txHash: tx.hash });
      } catch (dbErr) {
        console.error('Failed to insert approval record:', dbErr);
        res.json({ error: 'Failed to insert approval record' });
      }
      
    });
  
    /**
     * Api to get the custodial wallet address for a user 
     * This is to deposit USDC tokens into the custodial wallet
     */

    router.get('/getCustodialWallet', async (req, res) => {
      try{
        const { username } = req.query;
        let baseQuery = 'SELECT * FROM custodial_wallets where username = $1';
        const values = [username];  
        
        const result = await pool.query(baseQuery, values);
        console.log("Custodial wallets for user:", username, result.rows);
        res.json({
            message: 'Custodial wallets data retrieved',
            data: result.rows
          });
    
      } catch (err) {
        console.error('Error fetching custodial wallets:', err);
        res.status(500).json({ error: 'Internal Server Error' });
      }
    });

  router.post('/transferFrom', async (req, res) => {
    try {
       //NOTE: All APIs should send user_name as unique for request body
      const { user_name,fromAddress, toAddress, amount } = req.body;
      const parsed = ethers.parseUnits(amount.toString(), 6);
      var allowance = await testUSDC.allowance(fromAddress, signer.address);
      var balance = await testUSDC.balanceOf(fromAddress);
      console.log(`Transferring ${amount} USDC from ${fromAddress} to ${toAddress}`)
      console.log(`Allowance: ${ethers.formatUnits(allowance, 6)}, Balance: ${ethers.formatUnits(balance, 6)}`);
      if (allowance < parsed) return res.status(400).json({ error: 'Insufficient allowance' });
      if (balance < parsed) return res.status(400).json({ error: 'Insufficient balance' });
      const tx = await testUSDC.transferFrom(fromAddress, toAddress, parsed);
      await tx.wait();
      allowance = await testUSDC.allowance(fromAddress, signer.address);
      balance = await testUSDC.balanceOf(fromAddress);
      console.log(`Transferred ${amount} USDC from ${fromAddress} to ${toAddress}`)
      console.log(`Allowance: ${ethers.formatUnits(allowance, 6)}, Balance: ${ethers.formatUnits(balance, 6)}`);
       //TODO insert into DB user_name,fromAddress(owner address), toAddress (custodial Address), amount, allowance, balance, txhash, date-- done
      const insertQuery = `
      INSERT INTO amount_transfers (
        user_name, from_address, to_address, amount,
        allowance, balance, tx_hash
      ) VALUES ($1, $2, $3, $4, $5, $6, $7)
    `;
     const insertValues = [
      user_name,
      fromAddress,
      toAddress,
      amount,
      ethers.formatUnits(allowance, 6),
      ethers.formatUnits(balance, 6),
      tx.hash
     ];

      await pool.query(insertQuery, insertValues);
      console.log('Transfer record inserted into amount_transfers');
      res.json({ txHash: tx.hash });
     } catch (dbErr) {
      console.error('DB insert error:', dbErr);
     }
    
      
    });
  

    router.get('/:walletAddress/balance', async (req, res) => {
      try{
        console.log(':walletAddress',req.params.walletAddress);
        const walletAddress = req.params.walletAddress;
        const balance = await testUSDC.balanceOf(walletAddress);
        res.json({ balance: ethers.formatUnits(balance, 6) });
      }catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Failed to retrieve balance' });
      }     
    });
    // routes code -end

    module.exports = router;