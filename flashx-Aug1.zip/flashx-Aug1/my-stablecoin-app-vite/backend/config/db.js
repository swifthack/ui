// A module to export the initialized connection
const { Pool } = require('pg');
const pool = new Pool({ 
        user: 'psbabu007',        // Your PostgreSQL username
        host: 'localhost',             // Your database host (usually localhost for local setup)
        database: 'mydatabase',      // The database name you created
        password: 'babu1234pop', // The password for your database user
        port: 5432,                    // The default PostgreSQL port
        max: 20,                       // Maximum number of clients in the pool
 });

pool.connect((err, client, release) => {
  if (err) return console.error('Error acquiring client', err.stack);
  console.log('Database connected successfully (Central Config)!');
  client.release();
});

module.exports = pool;